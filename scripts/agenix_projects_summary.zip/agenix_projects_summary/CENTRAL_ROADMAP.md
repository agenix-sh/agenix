# AGEnix Unified Roadmap

Generated: 2025-11-16 10:56:16 UTC

## agx Roadmap

- Repo: https://github.com/agenix-sh/agx
- Open Issues:
42	OPEN	AGX-044: Implement action.submit semantics	architecture	2025-11-16T08:28:55Z
40	OPEN	AGX-043: Align nomenclature with EXECUTION-LAYERS (plan.submit & action.submit)	architecture	2025-11-16T07:54:18Z
39	OPEN	AGX-042: Add interactive PLAN REPL	architecture	2025-11-15T20:40:03Z
22	OPEN	AGX-022: Abstract planner model backend	architecture	2025-11-15T15:57:56Z
9	OPEN	AGX-009: Research/Prototype llama.cpp Embedding	research	2025-11-15T15:58:03Z
8	OPEN	AGX-008: Add CI Pipeline (cargo fmt + clippy)	governance	2025-11-15T15:58:15Z

## agq Roadmap

- Repo: https://github.com/agenix-sh/agq
- Open Issues:
20	OPEN	AGQ-015: Add plan query and search API		2025-11-15T20:16:17Z
19	OPEN	AGQ-014: Implement plan storage and versioning		2025-11-15T20:15:16Z
18	OPEN	AGQ-013: Add queue discovery and management		2025-11-15T20:12:27Z
17	OPEN	AGQ-012: Implement failed job handling and retry logic		2025-11-15T20:11:45Z
16	OPEN	AGQ-011: Implement RPOPLPUSH for atomic queue transitions		2025-11-15T20:04:15Z
10	OPEN	AGQ-010: Add structured logging and error handling		2025-11-15T09:37:47Z
9	OPEN	AGQ-009: Add PLAN submission endpoint		2025-11-15T09:37:46Z
8	OPEN	AGQ-008: Implement RESP command router		2025-11-15T09:37:45Z
7	OPEN	AGQ-007: Implement worker heartbeat registry		2025-11-15T09:37:43Z
6	OPEN	AGQ-006: Implement job metadata storage		2025-11-15T09:37:41Z
5	OPEN	AGQ-005: Implement ZADD-based scheduling queue		2025-11-15T09:37:40Z

## agw Roadmap

- Repo: https://github.com/agenix-sh/agw
- Open Issues:
18	OPEN	AGW-012: Align codebase nomenclature with EXECUTION-LAYERS.md		2025-11-16T07:59:08Z
10	OPEN	AGW-010: Add structured logging and error handling		2025-11-15T10:07:40Z
9	OPEN	AGW-009: Implement shutdown and job interruption		2025-11-15T10:07:38Z
8	OPEN	AGW-008: Implement tool availability metadata		2025-11-15T10:07:36Z
7	OPEN	AGW-007: Implement result posting to AGQ		2025-11-15T10:07:35Z

